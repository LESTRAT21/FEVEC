This module allows you to store animal information.
