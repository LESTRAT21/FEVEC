* Go to Animals
* Create an animal by entering his name and selecting his gender, species, breed and
  color.
